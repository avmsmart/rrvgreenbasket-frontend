"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import {
  Package,
  MapPin,
  Heart,
  ShoppingBag,
  ArrowRight,
  Sparkles,
  Leaf,
  Clock,
  Phone,
  CheckCircle2,
} from "lucide-react";
import { CustomerUser } from "@/types/customer-auth";
import { CustomerAddress } from "@/types/customer-address";
import customerAddressService from "@/services/customer-address.service";
import { INITIAL_ORDERS } from "@/data/customer-profile-mock";
import { useWishlist } from "@/context/WishlistContext";

interface CustomerOverviewProps {
  customer: CustomerUser | null;
  onNavigateTab: (tab: any) => void;
}

export const CustomerOverview: React.FC<CustomerOverviewProps> = ({
  customer,
  onNavigateTab,
}) => {
  const { wishlistCount } = useWishlist();
  const [defaultAddress, setDefaultAddress] = useState<CustomerAddress | null>(null);
  const [addressCount, setAddressCount] = useState<number>(0);

  const displayName = customer?.fullName?.trim() || "Valued Customer";
  const firstName = displayName.split(" ")[0];

  useEffect(() => {
    let active = true;

    async function loadQuickData() {
      try {
        const addresses = await customerAddressService.getMyAddresses();
        if (!active) return;

        setAddressCount(addresses.length);
        const def = addresses.find((address) => address.isDefault) || addresses[0] || null;
        setDefaultAddress(def);
      } catch {
        // Keep the overview usable if address loading fails.
      }
    }

    loadQuickData();

    return () => {
      active = false;
    };
  }, []);

  const latestOrder = INITIAL_ORDERS[0];

  return (
    <div className="min-w-0 space-y-8 text-slate-800 sm:space-y-10">
      {/* Welcome */}
      <section className="relative overflow-hidden border-b border-emerald-100 pb-7 sm:pb-8">
        <div className="pointer-events-none absolute right-2 top-0 hidden text-emerald-50 sm:block">
          <Leaf className="h-28 w-28" strokeWidth={1} />
        </div>

        <div className="relative flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0">
            <div className="mb-2 inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
              <Sparkles className="h-4 w-4" />
              RRV Green Basket Member
            </div>

            <h1 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
              Welcome back, {firstName}!
            </h1>

            <p className="mt-2 max-w-xl text-sm leading-6 text-slate-500">
              Manage your orders, delivery addresses and saved products in one place.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Link
              href="/"
              className="inline-flex min-h-10 items-center gap-2 rounded-lg bg-emerald-700 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-emerald-800"
            >
              <ShoppingBag className="h-4 w-4" />
              Shop products
            </Link>

            <button
              type="button"
              onClick={() => onNavigateTab("orders")}
              className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-emerald-200 px-4 py-2.5 text-sm font-semibold text-emerald-800 transition hover:bg-emerald-50"
            >
              <Package className="h-4 w-4" />
              Track orders
            </button>
          </div>
        </div>
      </section>

      {/* Account activity - simple inline stats, not cards */}
      <section aria-label="Account activity">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">Your account</h2>
          <span className="text-xs text-slate-400">Quick overview</span>
        </div>

        <div className="grid grid-cols-2 divide-y divide-slate-200 border-y border-slate-200 sm:grid-cols-4 sm:divide-x sm:divide-y-0">
          <button
            type="button"
            onClick={() => onNavigateTab("orders")}
            className="flex min-w-0 items-center gap-3 py-4 pr-3 text-left transition hover:bg-emerald-50/50 sm:px-4 sm:first:pl-0"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-700">
              <Package className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block text-lg font-bold leading-5 text-slate-900">{INITIAL_ORDERS.length}</span>
              <span className="mt-1 block text-xs text-slate-500">Orders</span>
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab("addresses")}
            className="flex min-w-0 items-center gap-3 py-4 pl-3 text-left transition hover:bg-emerald-50/50 sm:px-4"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-50 text-blue-700">
              <MapPin className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block text-lg font-bold leading-5 text-slate-900">{addressCount}</span>
              <span className="mt-1 block text-xs text-slate-500">Addresses</span>
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab("wishlist")}
            className="flex min-w-0 items-center gap-3 border-t border-slate-200 py-4 pr-3 text-left transition hover:bg-emerald-50/50 sm:border-t-0 sm:px-4"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-rose-50 text-rose-600">
              <Heart className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block text-lg font-bold leading-5 text-slate-900">{wishlistCount}</span>
              <span className="mt-1 block text-xs text-slate-500">Wishlist</span>
            </span>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab("settings")}
            className="flex min-w-0 items-center gap-3 border-t border-slate-200 py-4 pl-3 text-left transition hover:bg-emerald-50/50 sm:border-t-0 sm:px-4 sm:last:pr-0"
          >
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-50 text-amber-700">
              <Leaf className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-bold leading-5 text-slate-900">Zero-Plastic</span>
              <span className="mt-1 block text-xs text-slate-500">Packaging</span>
            </span>
          </button>
        </div>
      </section>

      {/* Address and recent order - distinct sections, no outer cards */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2 lg:gap-10">
        <section className="min-w-0">
          <div className="flex items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
              <MapPin className="h-5 w-5 text-emerald-700" />
              Default delivery address
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab("addresses")}
              className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-900"
            >
              All addresses <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {defaultAddress ? (
            <div className="py-5">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wide text-emerald-800">
                  {defaultAddress.addressType}
                </span>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  Default address
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900">
                {defaultAddress.receiverName}
              </h3>

              <p className="mt-1 text-sm leading-6 text-slate-600">
                {defaultAddress.addressLine1}
                {defaultAddress.addressLine2 ? `, ${defaultAddress.addressLine2}` : ""}
              </p>

              <p className="text-sm leading-6 text-slate-600">
                {defaultAddress.city}, {defaultAddress.state} – {defaultAddress.pincode}
              </p>

              <p className="mt-2 inline-flex items-center gap-2 text-sm text-slate-500">
                <Phone className="h-4 w-4 text-emerald-700" />
                {defaultAddress.receiverMobile}
              </p>
            </div>
          ) : (
            <div className="py-6">
              <p className="text-sm text-slate-500">You haven't saved a delivery address yet.</p>
              <button
                type="button"
                onClick={() => onNavigateTab("addresses")}
                className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 hover:text-emerald-900"
              >
                <MapPin className="h-4 w-4" />
                Add delivery address
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

          <div className="flex items-center justify-between gap-3 border-t border-slate-200 pt-3 text-xs">
            <span className="text-slate-500">Fast daily delivery slot</span>
            <span className="font-semibold text-emerald-800">6:00 AM – 8:00 AM</span>
          </div>
        </section>

        <section className="min-w-0">
          <div className="flex items-center justify-between gap-3 border-b border-slate-200 pb-3">
            <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
              <Package className="h-5 w-5 text-emerald-700" />
              Recent order
            </h2>
            <button
              type="button"
              onClick={() => onNavigateTab("orders")}
              className="inline-flex shrink-0 items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-900"
            >
              Order history <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {latestOrder ? (
            <div className="py-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-sm font-bold text-slate-900">{latestOrder.id}</span>
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {latestOrder.status}
                </span>
              </div>

              <p className="mt-1 text-xs text-slate-500">
                {latestOrder.date} <span className="px-1">·</span>
                {latestOrder.items.length} items <span className="px-1">·</span>
                <span className="font-semibold text-slate-700">₹{latestOrder.total}</span>
              </p>

              <div className="mt-4 flex items-center gap-2 overflow-x-auto pb-1">
                {latestOrder.items.slice(0, 3).map((item) => (
                  <img
                    key={item.id}
                    src={item.image}
                    alt={item.name}
                    className="h-11 w-11 shrink-0 rounded-lg object-cover"
                  />
                ))}
                {latestOrder.items.length > 3 && (
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-xs font-bold text-slate-600">
                    +{latestOrder.items.length - 3}
                  </span>
                )}
              </div>
            </div>
          ) : (
            <div className="py-6">
              <p className="text-sm text-slate-500">You haven't placed an order yet.</p>
              <Link href="/" className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700">
                <ShoppingBag className="h-4 w-4" />
                Start shopping
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          )}

          <div className="flex items-center justify-between gap-3 border-t border-slate-200 pt-3 text-xs">
            <span className="inline-flex items-center gap-1.5 text-slate-500">
              <Clock className="h-3.5 w-3.5 text-emerald-700" />
              Freshly harvested daily
            </span>
            <button
              type="button"
              onClick={() => onNavigateTab("orders")}
              className="font-semibold text-emerald-700 hover:text-emerald-900"
            >
              Track details →
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default CustomerOverview;
