"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  LayoutDashboard,
  User,
  Package,
  MapPin,
  Heart,
  Settings,
  HelpCircle,
  ShoppingBag,
  ArrowLeft,
  Loader2,
  ChevronRight,
  LogOut,
  Leaf,
} from "lucide-react";
import { useCustomerAuth } from "@/context/CustomerAuthContext";
import CustomerNavAuth from "@/components/customer/CustomerNavAuth";
import CustomerLogoutDialog from "@/components/customer/CustomerLogoutDialog";
import CustomerProfileSidebar, { ProfileTab } from "./CustomerProfileSidebar";

interface CustomerProfileLayoutProps {
  currentTab: ProfileTab;
  onTabChange: (tab: ProfileTab) => void;
  children: React.ReactNode;
}

const MOBILE_MENU_ITEMS: {
  id: ProfileTab | "logout";
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: "addresses", label: "My Addresses", icon: MapPin },
  { id: "profile", label: "Account", icon: User },
  { id: "orders", label: "My Orders", icon: Package },
  { id: "wishlist", label: "My Wishlist", icon: Heart },
  { id: "settings", label: "Account Settings", icon: Settings },
  { id: "support", label: "Help & Support", icon: HelpCircle },
  { id: "logout", label: "Logout", icon: LogOut },
];

const MOBILE_BOTTOM_TABS: {
  id: ProfileTab | "shop";
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}[] = [
  { id: "shop", label: "Shop", icon: ShoppingBag },
  { id: "orders", label: "Orders", icon: Package },
  { id: "wishlist", label: "Wishlist", icon: Heart },
  { id: "addresses", label: "Addresses", icon: MapPin },
  { id: "profile", label: "Profile", icon: User },
];

export const CustomerProfileLayout: React.FC<CustomerProfileLayoutProps> = ({
  currentTab,
  onTabChange,
  children,
}) => {
  const router = useRouter();
  const { customer, isAuthenticated, isLoading, logout } = useCustomerAuth();
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const handleLogoutConfirm = async () => {
    setIsLoggingOut(true);
    try {
      await logout();
      setShowLogoutModal(false);
      router.push("/");
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      setIsLoggingOut(false);
    }
  };

  if (isLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f8faf7] p-8">
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-emerald-700" />
          <p className="text-xs font-semibold text-emerald-900">
            Loading your profile...
          </p>
        </div>
      </main>
    );
  }

  const hasAuth = isAuthenticated && Boolean(customer?.mobileNumber);

  if (!hasAuth) {
    return (
      <main className="min-h-screen bg-[#f8faf7] text-gray-900">
        <header className="sticky top-0 z-40 flex items-center justify-between border-b border-gray-100 bg-white px-5 py-4 sm:px-10">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-3xl">🧺</span>
            <span className="text-lg font-black tracking-tight text-emerald-900">
              RRV Green Basket
            </span>
          </Link>
          <CustomerNavAuth />
        </header>

        <div className="mx-auto max-w-md px-5 py-20 text-center">
          <div className="space-y-4 rounded-3xl border border-gray-100 bg-white p-8 shadow-sm">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-emerald-50 text-emerald-700">
              <User className="h-8 w-8" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-gray-900">
              Customer Account
            </h1>
            <p className="text-xs leading-relaxed text-gray-500">
              Please sign in with your mobile number to view and manage your
              delivery addresses, orders and preferences.
            </p>
            <Link
              href="/login?redirect=/customer/profile"
              className="mt-2 block w-full rounded-xl bg-emerald-700 py-3 text-xs font-bold text-white transition hover:bg-emerald-800"
            >
              Sign In with Mobile OTP →
            </Link>
            <Link
              href="/"
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-gray-500 hover:text-emerald-800"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Storefront
            </Link>
          </div>
        </div>
      </main>
    );
  }

  const customerName = customer?.fullName?.trim() || "Customer";
  const initials = customerName
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");

  const handleMobileMenuClick = (id: ProfileTab | "logout") => {
    if (id === "logout") {
      setShowLogoutModal(true);
      return;
    }
    onTabChange(id);
  };

  return (
    <main className="min-h-screen bg-[#f8faf7] pb-20 text-gray-900 lg:pb-0">
      {/* Header */}
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-gray-100 bg-white/95 px-4 py-3 backdrop-blur sm:px-8">
        <div className="flex min-w-0 items-center gap-3 sm:gap-4">
          <Link href="/" className="flex min-w-0 items-center gap-2">
            <span className="text-3xl">🧺</span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-black leading-tight text-emerald-950 sm:text-base">
                RRV Green Basket
              </span>
              <span className="hidden text-[10px] font-semibold text-emerald-700 sm:block">
                Customer Account
              </span>
            </span>
          </Link>

          <span className="hidden text-gray-200 sm:inline">|</span>

          <Link
            href="/"
            className="hidden items-center gap-1.5 text-xs font-bold text-emerald-800 transition hover:text-emerald-950 sm:inline-flex"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Storefront
          </Link>
        </div>

        <div className="flex shrink-0 items-center gap-2 sm:gap-3">
          <Link
            href="/cart"
            aria-label="Shopping cart"
            className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-white px-3 py-2 text-xs font-semibold text-gray-700 transition hover:border-emerald-200 hover:bg-emerald-50"
          >
            <ShoppingBag className="h-4 w-4 text-emerald-700" />
            <span className="hidden sm:inline">Cart</span>
          </Link>
          <CustomerNavAuth />
        </div>
      </header>

      {/* Main content */}
      <div className="mx-auto max-w-[1440px] px-4 py-5 sm:px-6 sm:py-6 lg:px-8">
        <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[280px_minmax(0,1fr)]">
          {/* Desktop sidebar */}
          <aside className="sticky top-20 hidden lg:block">
            <CustomerProfileSidebar
              currentTab={currentTab}
              onTabChange={onTabChange}
              customer={customer}
              onLogoutClick={() => setShowLogoutModal(true)}
            />
          </aside>

          {/* Mobile profile menu: shown when Profile tab is selected */}
          {currentTab === "profile" && (
            <section className="mx-auto w-full max-w-xl lg:hidden">
              <div className="pb-7 pt-3">
                <div className="flex items-start justify-between">
                  <div className="flex h-[76px] w-[76px] items-center justify-center overflow-hidden rounded-full bg-emerald-700 text-2xl font-bold text-white ring-4 ring-emerald-50">
                    {initials || <User className="h-8 w-8" />}
                  </div>
                  <span className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                    <Leaf className="h-3.5 w-3.5" />
                    Green Basket Member
                  </span>
                </div>

                <h1 className="mt-5 text-2xl font-bold tracking-tight text-slate-900">
                  {customerName}
                </h1>
                <p className="mt-1 text-sm text-slate-500">
                  {customer?.mobileNumber}
                </p>
              </div>

              <nav aria-label="Profile settings" className="border-t border-slate-100">
                {MOBILE_MENU_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const isLogout = item.id === "logout";

                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleMobileMenuClick(item.id)}
                      className={`flex min-h-[58px] w-full items-center gap-4 border-b border-slate-100 px-1 py-3 text-left transition hover:bg-emerald-50/60 ${
                        isLogout ? "text-rose-600" : "text-slate-800"
                      }`}
                    >
                      <Icon
                        className={`h-[19px] w-[19px] shrink-0 ${
                          isLogout ? "text-rose-500" : "text-slate-400"
                        }`}
                        strokeWidth={1.9}
                      />
                      <span className="flex-1 text-sm font-medium">
                        {item.label}
                      </span>
                      <ChevronRight className="h-4 w-4 shrink-0 text-slate-300" />
                    </button>
                  );
                })}
              </nav>
            </section>
          )}

          {/* Main tab content. On mobile, Profile is represented by the menu above. */}
          <section className={`min-w-0 ${currentTab === "profile" ? "hidden lg:block" : "block"}`}>
            {children}
          </section>
        </div>
      </div>

      {/* Mobile bottom navigation */}
      <nav
        aria-label="Mobile account navigation"
        className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200 bg-white/95 px-1 pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_16px_rgba(15,23,42,0.04)] backdrop-blur lg:hidden"
      >
        <div className="mx-auto grid max-w-xl grid-cols-5">
          {MOBILE_BOTTOM_TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive =
              tab.id === "shop" ? false : currentTab === tab.id;

            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  if (tab.id === "shop") {
                    router.push("/");
                  } else {
                    onTabChange(tab.id);
                  }
                }}
                className={`flex min-h-[58px] flex-col items-center justify-center gap-1 px-1 text-[10px] font-medium transition ${
                  isActive ? "text-emerald-700" : "text-slate-400 hover:text-emerald-700"
                }`}
              >
                <Icon
                  className={`h-[19px] w-[19px] ${isActive ? "text-emerald-700" : "text-slate-400"}`}
                  strokeWidth={isActive ? 2.4 : 1.8}
                />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      <CustomerLogoutDialog
        isOpen={showLogoutModal}
        onClose={() => setShowLogoutModal(false)}
        onConfirm={handleLogoutConfirm}
        isLoggingOut={isLoggingOut}
      />
    </main>
  );
};

export default CustomerProfileLayout;
